IL MIO PATRIMONIO

La cartella contiene una mini-app per:
- impostare il patrimonio iniziale del mese
- aggiungere le spese giorno per giorno
- vedere automaticamente patrimonio residuo e totale speso
- eliminare le spese
- conservare i dati sul dispositivo/browser tramite memoria locale

Per usarla subito:
1. Apri index.html con Safari o un browser.
2. Inserisci il patrimonio iniziale.
3. Aggiungi le spese.

Per avere l'icona direttamente nella Home dell'iPhone come una vera web-app, il file deve essere pubblicato su un indirizzo HTTPS. Il manifest è già incluso nel pacchetto.
